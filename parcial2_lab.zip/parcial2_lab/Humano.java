package parcial2_lab;

import java.util.ArrayList;
import java.util.Scanner;

public class Humano {

    private char [] [] ADN = new char[6][6];


    public void humano(){

    }

    public void IngresarAdn(){
        Scanner sc = new Scanner(System.in);
        String cadena;
        boolean n;
        char [] [] semi_adn = new char[6][6];
        for(int i = 0; i<6; i++){
            cadena = "";
            n = false;
            //En esta función uso un regex para facilitar la verificación de datos ingresados
            while(!n) {
                System.out.println("Ingrese la cadena de ADN número "+ (i+1));
                System.out.println("""
                        La cadena de ADN debe tener:
                        1)Solamente 6 caráctes
                        2)Solamente puede tener las letras A,T,C y G
                        3) Sin espacios""");
                cadena = sc.nextLine().toUpperCase();
                n = cadena.matches("^[A,T,C,G]{6}$");
            }

            //Acá recorró el String ingresado y lo guardo en la matriz de char[][] para luego pasarlo al atributo ADN
            for(int l = 0; l<6;l++) {
                semi_adn[i][l] = cadena.charAt(l);
            }
            System.out.println("""
                    
                    La cadena se ha cargado correctamente.
                    
                    """);

        }
        for(int i = 0; i <6; i++){
            for(int j = 0; j <6; j++){
                System.out.print(semi_adn[i][j]+ "  ");
            }
            System.out.println("""
                    
                    """);
        }
        //Acá envió los char guardados en la matriz semi_adn para guardarlos al atributo ADN
        ADN = semi_adn;
    }

    public boolean IsMutant () {
        //Para probar los ejemplos de las cadenas de ADN comente el metodo IngresarAdn() y descomente la cadena de ADN que desea probar.
        //Esta cadena es la del ejemplo del pdf y devuelve true
        /*ADN = new char[][]{
                {'A','T','G','C','G','A'},
                {'C','A','G','T','G','C'},
                {'T','T','A','T','G','T'},
                {'A','G','A','A','G','G'},
                {'C','C','C','C','T','A'},
                {'T','C','A','C','T','G'}
        };*/


        //Esta cadena tambien devuelve true por una vertical y una diagonal
        /*ADN = new char[][]{
                {'A','T','G','C','G','A'},
                {'A','A','G','T','G','C'},
                {'A','A','C','T','C','T'},
                {'A','G','A','A','G','G'},
                {'C','C','C','A','T','A'},
                {'T','C','A','C','T','G'}
        };*/


        //Esta cadena devuelve false debido a que solamente hay una coincidencia de solo 1 cadena (la horizontal 6) en lugar de 2
        /*ADN = new char[][]{
                {'A','T','G','C','G','A'},
                {'A','A','G','T','G','C'},
                {'T','A','C','T','C','T'},
                {'A','G','G','A','G','G'},
                {'C','T','C','A','T','A'},
                {'T','T','T','T','T','T'}
        };*/


        IngresarAdn();

        //Las coincidencias que encuentran estas dos funciones se suman, y se verifica si hay más de dos cadenas de ADN mutantes
        int mutant = ObtenerDiagonales()+ ObtenerVerticalesHorizontales();
        if (mutant >=2){
            return true;
        }
        return false;
    }

    public int ObtenerDiagonales(){
        //Uso un arraylist que guarde arrays de tipo char[] ya que estos arrays son los que se guardan dentro de diagonal
        int x;
        int coincidence = 0;
        ArrayList<char[]> Diagonales = new ArrayList<>();
        char [] diagonal = new char [6];
        //Diagonal Principal
        for(int i = 0; i < 6; i++){
            for(int j = 0; j<6;j++){
                if (j == i){
                    diagonal[i] = ADN[i][j];
                }
            }
        }
        Diagonales.add(diagonal);


        // Diagonal Superior 1
        diagonal = new char [5];
        x = 1;
        for(int i = 0; i < 5; i++) {
            diagonal[i] = ADN[i][x];
            x+=1;
        }
        Diagonales.add(diagonal);

        //Diagonal Superior 2
        diagonal = new char[4];
        x = 2;
        for(int i = 0; i<4; i++){
            diagonal[i] = ADN [i][x];
            x+=1;
        }
        Diagonales.add(diagonal);

        //Diagonales Inferior 1
        diagonal = new char[5];
        x = 1;
        for(int i = 0; i < 5; i++) {
            diagonal[i] = ADN[x][i];
            x+=1;
        }
        Diagonales.add(diagonal);


        //Diagonal Inferior 2
        diagonal = new char[4];
        x = 2;
        for(int i = 0; i<4; i++){
            diagonal[i] = ADN [x][i];
            x+=1;
        }
        Diagonales.add(diagonal);




        //Diagonales inversas

        diagonal = new char[6];
        x = 5;
        for(int i = 0; i<6; i++){
            diagonal[i]= ADN [i][x];
            x-=1;
        }
        Diagonales.add(diagonal);


        //Diagonales Superiores 1

        diagonal = new char[5];
        x = 4;
        for(int i = 0; i<5; i++){
            diagonal[i]= ADN [i][x];
            x-=1;
        }
        Diagonales.add(diagonal);

        //Diagonal Superior 2
        diagonal = new char[4];
        x = 3;
        for(int i = 0; i<4; i++){
            diagonal[i]= ADN [i][x];
            x-=1;
        }
        Diagonales.add(diagonal);


        //Diagonales inferior 1
        diagonal = new char[5];
        x = 1;
        for(int i = 5; i>=1; i--){
            diagonal[x-1]= ADN [i][x];
            x+=1;
        }
        Diagonales.add(diagonal);


        //Diagonal Inferior 2
        diagonal = new char[4];
        x = 2;
        for(int i = 5; i>=2; i--){
            diagonal[x-2]= ADN [i][x];
            x+=1;
        }
        Diagonales.add(diagonal);
        //En este for se recorre el arraylist Diagonales, con un char[], ya que este ArrayList guarda este tipo de datos
        for (char[] ch : Diagonales) {
            for (int j = 0; j < ch.length - 3; j++) {
                // En este se busca las coincidencias de 4 carácteres seguidos, y se coloca un break en caso de que si hay más de 5 letras seguidas, solo cuente como 1 coincidencia
                if (ch[j] == ch[j + 1] && ch[j + 1] == ch[j + 2] && ch[j + 2] == ch[j + 3]) {
                    coincidence += 1;
                    break;
                }
            }
        }
        return coincidence;
    }

    public int ObtenerVerticalesHorizontales(){
        int coincidence = 0;
        char [] aux = new char[6];
        ArrayList <char[]> verticales_horizontales = new ArrayList<>();
        //En este for se guardan las horizontales
        for (int i = 0; i< ADN.length; i++){
            for (int j = 0; j < ADN.length; j++){
                aux[j] = ADN[i][j];
            }
            verticales_horizontales.add(aux);
            aux = new char[6];
        }
        //En este las  verticales
        for (int i = 0; i< ADN.length; i++){
            for (int j = 0; j < ADN.length; j++){
                aux[j] = ADN[j][i];
            }
            verticales_horizontales.add(aux);
            aux = new char[6];
        }

        //Aquí se usa un for muy parecido al de diagonales ya que se usa un ArrayList de <char []> para guardar todas las cadenas
        for(char [] ch:verticales_horizontales){
            for (int i = 0; i<ch.length-3;i++){
                // En este se busca las coincidencias de 4 carácteres seguidos, y se coloca un break en caso de que si hay más de 5 letras seguidas, solo cuente como 1 coincidencia
                if (ch[i] == ch[i + 1] && ch[i + 1] == ch[i + 2] && ch[i + 2] == ch[i + 3]){
                    coincidence+=1;
                    break;
                }
            }
        }



        return coincidence;
    }










}
