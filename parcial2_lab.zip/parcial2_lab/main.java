package parcial2_lab;

public class main {
    public static void main(String [] Args){
        
        Humano h = new Humano();;
        if (h.IsMutant()){
            System.out.println("El humano es mutante!!!");
        }else {
            System.out.println("El humano no es mutante");
        }
    }
}
