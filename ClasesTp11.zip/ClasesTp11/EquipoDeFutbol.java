package ClasesTp11;

import java.util.ArrayList;
import java.util.Locale;
import java.util.Scanner;

public class EquipoDeFutbol {
    ArrayList plantel;

    public EquipoDeFutbol (ArrayList plantel){
        this.plantel = plantel;
    }
    public void AgregarJugadores(){
        Scanner sc = new Scanner(System.in);
        System.out.println("Ingrese el nombre del jugador: ");
        String play = sc.nextLine().toUpperCase();
        plantel.add(play);
    }
    public void EliminarJugadores(){
        Scanner sc = new Scanner(System.in);
        String jugador = " ";
        while (!plantel.contains(jugador)){
            System.out.println("Que jugador desea eliminar de este equipo:  ");
            for(Object player:plantel){
                System.out.println(player);
            }
            jugador = sc.nextLine().toUpperCase();
            if (plantel.contains(jugador)){
                plantel.remove(plantel.indexOf(jugador));
                System.out.println("Se eliminó el jugador.");
                break;
            }
        }

    }



}
