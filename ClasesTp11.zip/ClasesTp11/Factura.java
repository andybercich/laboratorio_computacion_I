package ClasesTp11;

import java.util.ArrayList;
import java.util.Date;
import java.util.Objects;
import java.util.Scanner;

public class Factura {
     int NumeroFactura;
     String FechaEmision;
     String Cliente;
     ArrayList <String> Articulos = new ArrayList<>() ;
     ArrayList <Double> PrecioUnitario = new ArrayList<>();
     ArrayList <Integer> Cantidad = new ArrayList<>();
     double SubTotal;
     double IVA;
     double Total;
     public  Factura(int NumeroFactura,String FechaEmision,  String Cliente ){
         this.NumeroFactura = NumeroFactura;
         this.FechaEmision = FechaEmision;
         this.Cliente = Cliente;

    }
    public void AgregarArticulo  () {
        Scanner sc = new Scanner(System.in);
        String art = " ";
        double preciU = 0;
        int cant = 0;
        while (Objects.equals(art, " ")) {
            System.out.println("Ingresa el nombre del artículo: ");
            art = sc.nextLine().toUpperCase();
        }
        Articulos.add(art);
        while (preciU <= 0) {
            System.out.println("Ingresa el precio unitario del artículo: ");
            preciU = sc.nextDouble();
        }
        PrecioUnitario.add(preciU);
        while (cant <= 0) {
            System.out.println("Ingresa la cantidad de artículos: ");
            cant = sc.nextInt();
        }
        Cantidad.add(cant);

    }

    public void CalcularSubTotal(){
        if(Cantidad.isEmpty()){
            System.out.println("Por favor, primero ingresa el método para agregar artículos: ");
        } else {
            SubTotal = 0;
            System.out.println("Nro Factura: "+ NumeroFactura);
            System.out.println("Fecha de Emision: "+ FechaEmision);
            System.out.println("Cliente: "+ Cliente);
            for (int i = 0; i<Articulos.size(); i++){
                System.out.println("Artículo: "+ Articulos.get(i) + "        Precio Unitario: "+ PrecioUnitario.get(i) + "        Cantidad: "+ Cantidad.get(i));
                SubTotal +=  Math.round((PrecioUnitario.get(i) * Cantidad.get(i))*100)/100;
            }
            System.out.println("Sub Total: " + SubTotal);
        }
        System.out.println("""
           
           
           """);
    }
    public void CalcularIva(){
         if(SubTotal == 0){
             System.out.println("Por Favor, primero debe calcular el subtotal.");
         }else{
             IVA = 0;
             double porcentaje = 0;
             Scanner sc = new Scanner(System.in);
             while(porcentaje <= 0){
                 System.out.println("Ingrese el porcentaje de IVA: ");
                 porcentaje = sc.nextDouble();
             }
             IVA = Math.round((SubTotal*(porcentaje/100)) *100)/100;
             System.out.println("Nro Factura: "+ NumeroFactura);
             System.out.println("Fecha de Emision: "+ FechaEmision);
             System.out.println("Cliente: "+ Cliente);
             for (int i = 0; i<Articulos.size(); i++){
                 System.out.println("Artículo: "+ Articulos.get(i) + "        Precio Unitario: "+ PrecioUnitario.get(i) + "        Cantidad: "+ Cantidad.get(i));
             }
             System.out.println("Sub Total: " + SubTotal);
             System.out.println("IVA: " + IVA);
             System.out.println("""
           
           
           """);
        }
    }
    public void CalcularTotal(){
         if(IVA == 0){
             System.out.println("Primero debe calcular el IVA  por vafor: ");
         }else {
            Total = 0;
            Total = SubTotal + IVA;
             System.out.println("Nro Factura: "+ NumeroFactura);
             System.out.println("Fecha de Emision: "+ FechaEmision);
             System.out.println("Cliente: "+ Cliente);
             for (int i = 0; i<Articulos.size(); i++){
                 System.out.println("Artículo: "+ Articulos.get(i) + "        Precio Unitario: "+ PrecioUnitario.get(i) + "        Cantidad: "+ Cantidad.get(i));
             }
             System.out.println("Sub Total: " + SubTotal);
             System.out.println("IVA: " + IVA);
             System.out.println("Total: " + Total);
             System.out.println("""
           
            
           """);
         }
         }
    }


