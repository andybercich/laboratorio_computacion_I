package ClasesTp11;

import java.lang.reflect.Array;
import java.nio.channels.FileChannel;
import java.util.Objects;
import java.util.Scanner;

public class main_tp11 {
    public static Factura DatosIniciales(){
        Scanner sc = new Scanner(System.in);
        String NombreCli = " ";
        int day = 0;
        int mounth = 0;
        int year = 0;
        int NroFact = 0;

        while( NroFact<=0){
            System.out.println("Ingresa el número de factura: ");
            NroFact = sc.nextInt();
            sc.nextLine();
        }
        sc = sc.reset();
        while (NombreCli.equals(" ")){
            System.out.println("Ingresa el nombre del cliente: ");
            NombreCli = sc.nextLine().toUpperCase();
        }

        while(day<= 0 || day >31 ){
            System.out.println("Ingresa el dia de hoy: ");
            day = sc.nextInt();
        }
        while(mounth<= 0 || mounth >12 ){
            System.out.println("Ingresa el mes de hoy: ");
            mounth = sc.nextInt();
        }
        while(year< 2023 || year >2024 ){
            System.out.println("Ingresa el año de hoy: ");
            year = sc.nextInt();
        }
        String fecha = (day + "/" + mounth + "/"+ year);

        return new Factura(NroFact, fecha, NombreCli);

    }
    public static void main (String[] args ){
        Scanner sc = new Scanner(System.in);
        /*
        //Ejercicio 1
        String option = "1";
        ArrayList <String> autos = new ArrayList<>();
        while(Objects.equals(option, "1")){
            System.out.println("Ingrese el nombre del auto: ");
            String auto = sc.nextLine();
            auto = auto.toUpperCase();
            autos.add(auto);
            do {
                System.out.println("Desea ingresar otro auto? 1 = si  0 = No");
                option = sc.nextLine();
            }while (!Objects.equals(option, "0") && !Objects.equals(option, "1"));

            if(Objects.equals(option, "0")){
                for(String aut:autos){
                    System.out.println(aut);
                }
                break;
            }
        }

        //Ejercicio 2
        ArrayList <String> team1 = new ArrayList<>();
        EquipoDeFutbol number1 = new EquipoDeFutbol(team1);
        number1.AgregarJugadores();
        number1.EliminarJugadores();
        */

        //Ejercicio 3
        Factura f1 = new Factura(0,"","");
         f1 = DatosIniciales();
        String option2 = "1";
        while (option2.equals("1")){
            f1.AgregarArticulo();
            do {
                System.out.println("Si deseas agregar otro articulo, ingresa 1, sino 0: ");
                option2 = sc.nextLine();
            }while (!Objects.equals(option2, "0") && !Objects.equals(option2, "1"));
            if (option2.equals("0")){
                break;
            }
        }
        f1.CalcularSubTotal();
        f1.CalcularIva();
        f1.CalcularTotal();





    }
}
