package perrito.perrito;
import java.util.Objects;
import java.util.Scanner;

public class Uso_perrito {
    public static void main(String args []) {
        Scanner sc = new Scanner(System.in);
        //Ejercicio 1, 2, 3
        perrito perro1 = new perrito("Andy", "Pastor Aleman", 19);
        perro1.mostrarDatos();
        perro1.nombre = "Santi";
        perro1.setEdad(17);
        System.out.println(perro1.getEdad());
        perro1.mostrarDatos();
        System.out.println("El perro " + perro1.nombre + " hace " + perro1.ladrar());
        System.out.println("Ingrese el radio del circulo: ");

        //Ejercicio 4,5
        /*
        double radio = sc.nextDouble();
        circulo c1 = new circulo(radio);
        System.out.println("Su circunferencia es de: "+(c1.calcularCircun()));
        System.out.println("Su area es de: "+ (c1.calcularArea()));
        */

        //Ejercicio 9
        libro l1 = new libro("El señor de los anillos", "Tolkien", 1954);
        l1.mostrarDatos();

        //Ejercicio 11
        cuentaCorriente c1 = new cuentaCorriente(45000, 206);
        String option = "1";
        /*
        do {
            System.out.println("Ingrese que opcion desea realizar: ");
            System.out.println("1: Ingreso de dinero.     2: Retiro de dinero      0: Salir");
            option = sc.nextLine();

            if(Objects.equals(option, "1")){
                System.out.println("Ingrese el número de cuenta: ");
                int numeroc = sc.nextInt();
                System.out.println("Ingrese el dinero a ingresar");
                int ingre = sc.nextInt();
                c1.ingreso(numeroc,ingre);
            }

            if(Objects.equals(option, "2")){
                System.out.println("Ingrese el número de cuenta: ");
                int numeroc = sc.nextInt();
                System.out.println("Ingrese el dinero a ingresar");
                int reti = sc.nextInt();
                c1.retiro(numeroc,reti);
            }

        }while (!Objects.equals(option, "0"));
        */

        //Ejercicio 12
        rectangulo r1 = new rectangulo(15,5);
        r1.areaRec();
        r1.perimetroRec();

        //Ejercicio 14
        /*
        coche auto1 = new coche("Chevrolet", "Cruze", 2018, 250, 250);
        auto1.frenar(1);
        auto1.frenar(2);
        auto1.frenar(2);
        auto1.frenar(3);
        auto1.frenar(3);
        auto1.frenar(1);
        auto1.acelerar(2);
        auto1.acelerar(3);
        auto1.acelerar(3);
        auto1.acelerar(3);
        auto1.acelerar(2);
        auto1.acelerar(3);
         */
        //Ejercicio15
        peliculas peli1 = new peliculas("Spyderman", "Nolan", 150);
        peli1.datosPeli("spyderman");


    }
}
