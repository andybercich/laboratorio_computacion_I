package perrito.perrito;

public class perrito {
    public String nombre;
    public String raza;
    private int edad;

    public perrito(String nombre, String raza, int edad) {
        this.nombre = nombre;
        this.raza = raza;
        this.edad = edad;
    }
    public void setEdad(int edad){
        this.edad = edad;
    }
    public int getEdad(){
        return edad;
    }

    public void mostrarDatos(){
        System.out.println("nombre: "+ nombre + " edad: "+ edad+ " raza:"+ raza);
    }
    public String ladrar(){
        return  "Guau guau";
    }
}
