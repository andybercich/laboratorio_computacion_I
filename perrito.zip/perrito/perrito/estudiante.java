package perrito.perrito;
//Ejercicio 6,7
public class estudiante {
    public String nombre;
    public int edad;
    public int numero_id;
    public estudiante(String nombre, int edad, int numero_id){
        this.nombre = nombre;
        this.edad = edad;
        this.numero_id = numero_id;
    }

}

