package perrito.perrito;
//Ejercicio 13
public class coche {
    public String marca;
    public String modelo;
    public int fechaFabricacion;

    public int velocidad;
    public int maxvel;
public coche(String marca, String modelo, int fechaFabricacion, int velocidad, int maxvel){
    this.marca = marca;
    this.marca = modelo;
    this.fechaFabricacion = fechaFabricacion;
    this.velocidad = velocidad;
    this.maxvel = maxvel;
}
public void frenar(int puntoFreno){
    if(puntoFreno == 1 && (velocidad -30) >0){
        velocidad = velocidad-30;
        System.out.println("El auto ha frenado y ha disminuido la velocidad a "+ velocidad);
    } else if (puntoFreno == 2 && (velocidad-50) >0) {
        velocidad = velocidad-50;
        System.out.println("El auto ha frenado y ha disminuido la velocidad a "+ velocidad);
    } else if (puntoFreno == 3 && (velocidad -60) >0) {
        velocidad = velocidad-60;
        System.out.println("El auto ha frenado y ha disminuido la velocidad a "+ velocidad);
    }else if ((puntoFreno ==1 || puntoFreno == 2 || puntoFreno == 3) && ((velocidad-30)<=0 || (velocidad-50) <=0||(velocidad-60)<=0) ){
        velocidad = 0;
        System.out.println("El auto ha frenado y ha disminuido la velocidad por completo: "+ velocidad);
    }

}
    public void acelerar(int acelerador){
        if(acelerador == 1 && (velocidad +30) <=maxvel){
            velocidad = velocidad+30;
            System.out.println("El auto ha acelerado y ha aumentado la velocidad a "+ velocidad);
        } else if (acelerador == 2 && (velocidad+50) <=maxvel) {
            velocidad = velocidad+50;
            System.out.println("El auto ha acelerado y ha aumentado la velocidad a "+ velocidad);
        } else if (acelerador == 3 && (velocidad +60) <=maxvel) {
            velocidad = velocidad+60;
            System.out.println("El auto ha acelerado y ha aumentado la velocidad a "+ velocidad);
        }else if ((acelerador == 1 || acelerador==2 || acelerador==3) && (velocidad+30 >= maxvel||velocidad+50>=maxvel||velocidad+60>=maxvel)){
            velocidad = maxvel;
            System.out.println("El auto ha alcanzado su velocidad máxima: "+ velocidad);
        }

    }

}
