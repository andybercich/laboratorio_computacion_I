package perrito.perrito;

import java.util.Objects;

public class peliculas {
    public String nombre;
    public String director;
    public int duracion;

    public peliculas(String nombre, String director, int duracion){
        this.nombre = nombre;
        this.director = director;
        this.duracion = duracion;
    }
    public void datosPeli(String nom){
        if(nom.equalsIgnoreCase(nombre)){
            System.out.println("Pelicula: "+ nombre);
            System.out.println("Director: "+ director);
            System.out.println("Duracion: "+ duracion);
        }else {System.out.println("Nombre erroneo de la pelicula");}

    }
}
