package perrito.perrito;

//Ejercicio 8
public class libro {
    public String nombre;
    public String autor;
    public int fechaPubli;
    public libro (String nombre, String autor ,int fechaPubli){
        this.autor = autor;
        this.nombre = nombre;
        this.fechaPubli = fechaPubli;
    }
    public void mostrarDatos(){
        System.out.println("Autor: "+ autor+" Nombre: "+ nombre+ " Fecha de Publicacion: "+ fechaPubli);
    }
}
