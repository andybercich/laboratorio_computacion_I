package perrito.perrito;

//Ejercicio 10
public class cuentaCorriente {
    public int saldo;
    public int numeroCuenta;

    public cuentaCorriente(int saldo, int numeroCuenta) {
        this.saldo = saldo;
        this.numeroCuenta = numeroCuenta;
    }
    //Ejercicio 11
    public void retiro(int numeroCuenta2,int retiro){
        if(numeroCuenta2 == numeroCuenta && retiro < saldo){
            saldo = saldo -retiro;
            System.out.println("Se retiro: "+ retiro+" en la cuenta quedan: "+ saldo);
        }else if(numeroCuenta2 == numeroCuenta && retiro > saldo){
            System.out.println("El retiro es mayor al saldo en la cuenta, el cual es: "+ saldo);
        }else if(numeroCuenta2 != numeroCuenta){
            System.out.println("El numero de cuenta ingresado no coincide con el de esta cuenta");
        }
    }
    public void ingreso(int numeroCuenta3, int ingreso){
        if(numeroCuenta3==numeroCuenta && ingreso>0){
            saldo = saldo+ingreso;
            System.out.println("Se ha ingresado "+ ingreso+" pesos a la cuenta, dando un total de saldo de: "+ saldo);
        } else if (numeroCuenta3!=numeroCuenta) {
            System.out.println("El numero de cuenta no coincide con la cuenta usada.");
        } else if (numeroCuenta3==numeroCuenta && ingreso<0) {
            System.out.println("El ingreso especificado no puede ser negativo: ");
        }

    }
}