package perrito.perrito;
//Ejercicio 12
public class rectangulo {
    public int alto;
    public int ancho;

    public rectangulo(int alto, int ancho){
        this.alto = alto;
        this.ancho = ancho;
    }
    public void perimetroRec(){
        System.out.println ("El perimertro del rectangulo es: "+ ((2*ancho)+(2*alto)));
    }
    public void areaRec(){
        System.out.println("El area del rectangulo es: "+ ancho*alto);
    }
}
