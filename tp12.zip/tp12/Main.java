package tp12;
import java.util.Scanner;
import java.util.Objects;

import static java.util.regex.Pattern.matches;

public class Main {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        /*
        System.out.println("Ejercicio 2 y 3: ");
        Scanner sc = new Scanner(System.in);
        DatoUsuario d = new DatoUsuario();
        String option = "1";

        BaseUsuarios b1 = new BaseUsuarios();

        while (Objects.equals(option, "1")) {
            d.AgregarTelefono();
            d.AgregarMail();

            while (!b1.MailBase(d.ObtenerMail())) {
                System.out.println("El correo electrónico ya está en uso: ");
                d.AgregarMail();
            }

            d.AgregarNombre();

            while (!b1.NombreBase(d.ObtenerNombre())) {
                System.out.println("El nombre de usuario ya está en uso: ");
                d.AgregarNombre();
            }

            d.AgregarContra();

            b1.AgregarUser(d.Objeto());

            do {
                System.out.println("Desea agregar otro usuario, ingrese 1 si es así, sino 0: ");
                option = sc.nextLine();
            } while (!Objects.equals(option, "0") && !Objects.equals(option, "1"));
        }
        do {
            System.out.println("Desea ver la contraseña de un usuario, ingrese 1 si es así, sino 0: ");
            option = sc.nextLine();
        }while (!Objects.equals(option, "0") && !Objects.equals(option, "1"));
        if (Objects.equals(option,"1")){

            b1.MostrarUsers();
            System.out.println(b1.MostrarDatos());

        }
         */

        System.out.println("Ejercicio 5: ");

        System.out.println("Comprobación de un String si tiene un número al final: ");
        String prueba = sc.nextLine();
        Boolean pruebaverifi = prueba.matches(".*\\d$");
        if(!pruebaverifi){
            System.out.println("El string no termina con un número");
        }else{
            System.out.println("El string termina con un número");
        }

        System.out.println("Comprobación de un String si tiene un número al principio: ");
         prueba = sc.nextLine();
         pruebaverifi = prueba.matches("^\\d.*");
         if(!pruebaverifi){
             System.out.println("El string no empieza con un número");
         }else {
            System.out.println("El string empieza con un número");
         }

        System.out.println("Comprobación de un String si tiene entre 5-10 carácteres: ");
        prueba = sc.nextLine();
        pruebaverifi = prueba.matches("^[A-Za-z]{5,10}$");

        if (!pruebaverifi) {
            System.out.println("El string no tiene entre 5-10 caracteres");
        } else {
            System.out.println("El string tiene entre 5-10 caracteres");
        }

        System.out.println("Comprobación de DNI(ingresalo con los números separados por guiones 45-785-987)");
        prueba = sc.nextLine();
        pruebaverifi = prueba.matches("^\\d{2}-\\d{3}-\\d{3}$");
        if (!pruebaverifi) {
            System.out.println("DNI ingresado incorrectamente");
        } else {
            System.out.println("DNI ingresado correctamente");
        }

        System.out.println("Comprobar si el string tiene ABC");
        prueba = sc.nextLine();
        pruebaverifi = (prueba.toLowerCase()).contains("abc");
        if (!pruebaverifi) {
            System.out.println("El string no posee ABC");
        } else {
            System.out.println("El string posee ABC");
        }


    }
}

