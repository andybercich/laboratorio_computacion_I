package tp12;

import java.util.ArrayList;
import java.util.Scanner;

public class DatoUsuario {
    private String NombreUsuario;
    String Mail;
    String NumeroTelefono;
    private String Contra;
    public void AgregarNombre(){
        Scanner sc = new Scanner(System.in);
        System.out.println("Ingresa tu nombre de usuario: ");
        String AuxN = sc.nextLine();
        boolean isn = AuxN.matches("^(?=.*[0-9])[a-zA-Z0-9]{3,19}$|^[a-zA-Z0-9]{3,19}(?=.*[0-9])$" );

        while(isn == false){
            System.out.println("El nombre de usuario debe cumplir con los siguientes requerimientos:");
            System.out.println("1) Debe contener al menos 1 número al principio o al final del nombre.");
            System.out.println("2) No debe contener caracteres especiales.");
            System.out.println("3) Debe tener entre 4 y 20 caracteres.");
            AuxN = sc.nextLine();
            isn = AuxN.matches("^(?=.*[0-9])[a-zA-Z0-9]{3,19}$|^[a-zA-Z0-9]{3,19}(?=.*[0-9])$");
        }
        NombreUsuario = AuxN;
        System.out.println("Dato usuario cargado correctamente");
    }
    public void AgregarMail(){

        Scanner sc = new Scanner(System.in);
        System.out.println("Ingrese su direccion de correo electrónico: ");
        String mail = sc.nextLine();
        boolean ism = mail.matches("^[A-Za-z0-9._%+-]+@(gmail\\.com|hotmail\\.com)$");
        while (!ism) {
            System.out.println("Ingrese una dirección de correo electrónico válida. Con @gmail.com o @hotmail.com al final");
            mail = sc.nextLine();
            ism = mail.matches("^[A-Za-z0-9._%+-]+@(gmail\\.com|hotmail\\.com)$");
        }
        System.out.println("Dato de correo electrónico cargado correctamente.");

        Mail = mail;
    }
    public void AgregarContra(){
        Scanner sc = new Scanner(System.in);
        System.out.println("Ingrese su Contraseña: ");
        String con = sc.nextLine();
        boolean isc = con.matches("^(?=.*[A-Za-z])(?=.*\\d)(?=.*[!@#$%^&*()_+])[A-Za-z\\d!@#$%^&*()_+]{8,}$");
        while (isc == false) {
            System.out.println("Ingrese una contraseña válida: ");
            System.out.println("""
                    1) Tener al menos 8 caracteres.
                    2) Contener al menos un número.
                    3) Contener al menos un carácter especial.""");
            con = sc.nextLine();
            isc = con.matches("^(?=.*[A-Za-z])(?=.*\\d)(?=.*[!@#$%^&*()_+])[A-Za-z\\d!@#$%^&*()_+]{8,}$");
        }
        System.out.println("Dato usuario cargado correctamente.");
        Contra = con;
    }
    public void AgregarTelefono() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Ingrese su número de teléfono: ");
        String tel = sc.nextLine();
        boolean ist = tel.matches("^\\d{10,12}$");
        while (ist == false) {
            System.out.println("Ingrese un numero de teléfono válido: ");
            System.out.println("1) Debe tener entre 10 y 12 digitos ");
            tel = sc.nextLine();
            ist = tel.matches("^\\d{10,12}$");
        }
        System.out.println("Dato usuario cargado correctamente.");
        NumeroTelefono = tel;
    }
    public String ObtenerNum (){
        return NumeroTelefono;
    }
    public String ObtenerMail (){
        return Mail;
    }
    public String ObtenerNombre (){
        return NombreUsuario;
    }
    public String ObtenerContra (){
        return Contra;
    }
    public ArrayList Objeto(){
        ArrayList <String> Datos = new ArrayList<>();
        Datos.add(NombreUsuario);
        Datos.add(Mail);
        Datos.add(Contra);
        Datos.add(NumeroTelefono);
        return Datos;
    }

}
