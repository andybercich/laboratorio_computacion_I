package tp12;
import java.util.ArrayList;
import java.util.Scanner;

public class BaseUsuarios {
    ArrayList <ArrayList<String>> Users;
    public BaseUsuarios() {
        Users = new ArrayList<>();
    }
    public boolean NombreBase(String m) {
        if (!Users.isEmpty()) {
            for (ArrayList<String> usuario : Users) {
                if (usuario.get(0).equals(m)) {
                    return false;
                }
            }
        }
        return true;
    }
    public boolean MailBase(String m) {
        if (!Users.isEmpty()) {
            for (ArrayList<String> usuario : Users) {
                if (usuario.get(1).equals(m)) {
                    return false;
                }
            }
        }
        return true;
    }
    public void AgregarUser(ArrayList <String> s){
        System.out.println("Se ha agregado el usuario correctamente");
        Users.add(s);
    }
    public void MostrarUsers() {
        int x = 1;
        for (ArrayList<String> usuario : Users) {
            System.out.print("Usuario " + x + ": "+ usuario.get(0));
            System.out.println();
            x += 1;
        }
    }
    public boolean NameExist(String m) {
        if (!Users.isEmpty()) {
            for (ArrayList<String> usuario : Users) {
                if (usuario.get(0).equals(m)) {
                    return true;
                }
            }
        }
        return false;
    }
    public String MostrarDatos() {
        Scanner sc = new Scanner(System.in);
        boolean b = false;
        String user;
        String cont;
        System.out.println("Ingresa el nombre de usuario (cuide mayúsculas y minúsculas): ");
        user = sc.nextLine();
        System.out.println("Ingresa la contraseña del usuario: ");
        cont = sc.nextLine();

        for (ArrayList<String> usuarios : Users) {
            if (usuarios.get(0).equals(user) && usuarios.get(2).equals(cont)) {
                user = usuarios.toString();
                b = true;
                break;
            }
        }
        if (b) {
            return user;
        } else {
            return "Usuario no encontrado o contraseña no válida";
        }
    }




}
