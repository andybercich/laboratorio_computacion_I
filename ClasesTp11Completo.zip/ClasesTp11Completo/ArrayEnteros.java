package ClasesTp11;

import java.util.ArrayList;

public class ArrayEnteros {

    ArrayList <Integer> ente;
    int promedio_arit=0;
    public  ArrayEnteros (ArrayList <Integer> ente){
        this.ente = ente;
    }

    public void Promedio() {
        int sum = 0;
        promedio_arit = 0;
        for(int nu:ente){
            sum +=nu;
        }
        promedio_arit = sum/ente.size();
        System.out.println("El promedio aritmético es: "+ promedio_arit);
    }
    public void IgualesPromedio (){
        int many = 0;
        if (promedio_arit == 0){
            System.out.println("Debe calcular primero el promedio con el método IgualesPromedio");
        }else {
            for(int nu:ente){
                if( nu==promedio_arit){
                    many +=1;
                }
            }
            System.out.println("Hay "+ many+" números iguales al promedio");
        }

    }

    public void MenoresPromedio (){
        int many = 0;
        if (promedio_arit == 0){
            System.out.println("Debe calcular primero el promedio con el método IgualesPromedio");
        }else {
            for(int nu:ente){
                if( nu<promedio_arit){
                    many +=1;
                }
            }
            System.out.println("Hay "+ many+" números menores al promedio");
        }
    }
    public void MayoresPromedio (){
        int many = 0;
        if (promedio_arit == 0){
            System.out.println("Debe calcular primero el promedio con el método IgualesPromedio");
        }else {
            for(int nu:ente){
                if( nu>promedio_arit){
                    many +=1;
                }
            }
            System.out.println("Hay "+ many+" números mayores al promedio");
        }
    }
    public void MostrarArray(){
        for(int n : ente){
            System.out.println(n);
        }
    }

}
