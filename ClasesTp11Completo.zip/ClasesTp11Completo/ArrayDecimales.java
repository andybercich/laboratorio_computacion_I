package ClasesTp11;

import java.util.ArrayList;
import java.util.Scanner;

public class ArrayDecimales {

    public ArrayList <Double> decimales;
    public ArrayDecimales(ArrayList <Double>decimales){
        this.decimales = decimales;
    }

    public void MayorMenorDecimal (){
        double max = 0;
        for(double dec:decimales){
            if(dec > max){
                max = dec;
            }
        }
        System.out.println("El número mayor del array es: "+ max);
        double min = max;
        for(double dec:decimales){
            if(dec<min){
                min = dec;
            }
        }
        System.out.println("El número menor del array es: "+ min);
        if (min<0 && max >0){
            System.out.println("El rango entre el menor y el mayor es de: " + (min+max));
        } else if (max<0 && min<0) {
            System.out.println("El rango entre el menor y el mayor es de: " + (max-(-min)));
        }else if(max>0 && min >0) {
            System.out.println("El rango entre el menor y el mayor es de: " + (max-min));
        }

    }


}
